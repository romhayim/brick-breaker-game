import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

public class Racket extends Rectangle{
    BrickBreakerPanel panel;
Racket(){
    super();
}
    Racket(int x, int y, int width, int height, BrickBreakerPanel panel)
    {
        super(x, y, width, height);
        this.panel = panel;
    }

    public void draw(Graphics g) {
        ImageIcon ii = new ImageIcon("bat.png");
        Image racketImage = ii.getImage();
        //String score = "" + panel.score;

        g.drawImage(racketImage, x, y, width, height, null);
        g.setFont(new Font("Calibri", 1, 20));
        //g.drawString(score, x + width/2 - 5 * score.length(), y + height + 20);
    }
}
