import javax.swing.*;
import java.awt.*;

public class ScoreScreen extends Thread{

    int x, y, width, height;
    BrickBreakerPanel panel;
    Image img;

    ScoreScreen(int x, int y, int width, int height, BrickBreakerPanel panel)
    {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.panel = panel;
        this.img = new ImageIcon("data_screen.png").getImage();
    }

    public void draw(Graphics g)
    {
        g.drawImage(img, x, y, width, height, null);
        String scoreText = "" + panel.score;
        g.setColor(Color.ORANGE);
        g.drawString(scoreText, x + width/2 - 5 * scoreText.length(), y + height/2 + 6);
    }

    @Override
    public void run() {
        Racket r = panel.racket;

        while(true)
        {
            int dx = 0;

            if(x < r.x)
            {
               dx = 1;
            }
            else if(x > r.x)
            {
                dx = -1;
            }

            x += dx;

            try {
                Thread.sleep(2);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
