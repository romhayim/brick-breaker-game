import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.font.FontRenderContext;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.Socket;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;


public class BrickBreakerPanel extends JPanel implements Runnable {

    Brick[][] bricks = new Brick[5][5];
    Ball ball;
    Racket racket;
    String messege;
    int opponent_score;

    boolean opponent_ingame = false;
    Socket socket;
    int broken_brick_i = -1, broken_brick_j = -1;
    int broken_live;
    Racket opponent_racket;
    InputStream inputStream;
    OutputStream outputStream;
    ObjectInputStream objectInputStream;
    ObjectOutputStream objectOutputStream;
    ScoreScreen scoreScreen;

    int score;
    int number_of_bricks = 0;
    boolean game_ended = false;

    Image bg;
    int bgPosX, bgSpeed;

    private void initsocket() {
        opponent_racket = new Racket();
        try {
            socket = new Socket("localhost", 8888); // connect to the server on localhost on port 8888
            socket.setTcpNoDelay(true);
            outputStream = socket.getOutputStream();
            objectOutputStream = new ObjectOutputStream(new BufferedOutputStream(outputStream));
            inputStream = socket.getInputStream();
            objectInputStream = new ObjectInputStream(new BufferedInputStream(inputStream));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    BrickBreakerPanel() {
        initsocket();
        bg = new ImageIcon("background2.jpeg").getImage();
        bgPosX = 0;
        bgSpeed = 1;

        score = 0;

        Random rnd = new Random();
        for (int i = 0; i < bricks.length; i++) {
            for (int j = 0; j < bricks[i].length; j++) {
                bricks[i][j] = new Brick(j * 142 + 320, i * 50 + 20, 75, 30, this, i, j);
            }
        }

        this.racket = new Racket(540, 600, 120, 20, this);
        this.ball = new Ball(rnd.nextInt(200), rnd.nextInt(200), 25, this);
        this.scoreScreen = new ScoreScreen(racket.x, racket.y + racket.height + 40, racket.width, 30, this);


        //new Thread(racket).start();
        this.ball.start();
        this.scoreScreen.start();
        for (int i = 0; i < bricks.length; i++) {
            for (int j = 0; j < bricks[i].length; j++) {
                new Thread(bricks[i][j]).start();
            }
        }

        addMouseMotionListener(new MMA());
        hideMouseCursor();

        Thread t = new Thread(this);
        t.start();
    }

    @Override
    public void run() {
        while (!game_ended || !opponent_ingame) {

            try {
                Thread.sleep(2);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }

    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        bgPosX = (bgPosX > this.getWidth()) ? 0 : bgPosX;
        g.drawImage(bg, bgPosX, 0, this.getWidth(), this.getHeight(), null);
        g.drawImage(bg, bgPosX - this.getWidth(), 0, this.getWidth(), this.getHeight(), null);
        bgPosX += bgSpeed;

        if (!game_ended || !opponent_ingame) {
            if (number_of_bricks == 25) {
                System.out.println("nigga 1");
                game_ended = true;
            }

            for (int i = 0; i < bricks.length; i++) {
                for (int j = 0; j < bricks[i].length; j++) {
                    if (bricks[i][j].lives != 0) {
                        bricks[i][j].x = j * ((this.getWidth() / 9 >= 90) ? this.getWidth() / 9 : 90) + this.getWidth() / 4;
                        bricks[i][j].draw(g);
                    }
                }
            }

            Data d1, d2;
            try {
                d1 = new Data(racket.x, racket.y, broken_brick_i, broken_brick_j, broken_live, game_ended, score);
                objectOutputStream.writeObject(d1);
                objectOutputStream.flush();
                d2 = (Data) objectInputStream.readObject();
                System.out.println(d2.toString());
                opponent_racket.y = d2.y;
                opponent_racket.x = d2.x;
                opponent_score = d2.score;
                if (d2.brick_i != -1) {
                    bricks[d2.brick_i][d2.brick_j].lives = d2.live;
                    if (d2.live == 0 && bricks[d2.brick_i][d2.brick_j].checked != false)
                        bricks[d2.brick_i][d2.brick_j].checked = false;
                    number_of_bricks += 1;
                }
                opponent_ingame = d2.ingame;
                messege = score > opponent_score ? "Win" : "opponent win";
                if (score == opponent_score)
                    messege = "draw";
            } catch (IOException | ClassNotFoundException e) {
                System.out.println("nigger got catched");

                throw new RuntimeException(e);
            }

            racket.y = this.getHeight() - 150;
            scoreScreen.y = this.getHeight() - 110;
            ball.draw(g);
            racket.draw(g);
            scoreScreen.draw(g);

        } else {
            System.out.println(!game_ended || !opponent_ingame);
            Font f = new Font("Calibri", 1, 120);
            g.setFont(f);
            g.setColor(Color.LIGHT_GRAY);

            Rectangle2D r = f.getStringBounds(messege, new FontRenderContext(null, true, true));
            int textX = (int) (this.getWidth() / 2 - r.getWidth() / 2);
            int textY = (int) (this.getHeight() / 2);
            g.drawString(messege, textX, textY);
            setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        }
    }

    class MMA extends MouseMotionAdapter {
        @Override
        public void mouseMoved(MouseEvent e) {

            if (e.getX() < getWidth() - racket.width) {
                racket.x = e.getX();
            }

        }
    }

    public void hideMouseCursor() {
        //Transparent 16 x 16 pixel cursor image.
        BufferedImage cursorImg = new BufferedImage(16, 16, BufferedImage.TYPE_INT_ARGB);

        // Create a new blank cursor.
        Cursor blankCursor = Toolkit.getDefaultToolkit().createCustomCursor(
                cursorImg, new Point(0, 0), "blank cursor");

        // Set the blank cursor to the JPanel.
        setCursor(blankCursor);
    }
}
