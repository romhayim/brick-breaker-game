public class Rectangle {

    public int x, y, width, height;

    boolean isInCollision;

Rectangle(){}
    Rectangle(int x, int y, int width, int height)
    {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        isInCollision = false;
    }

    public int[] collision(Ball b)
    {
        int [] directions = {1, 1};

        if(b.x >= this.x - b.width/2 && b.x <= this.x + this.width + b.width/2
                && b.y >= this.y - b.width/2 && b.y <= this.y + this.height + b.width/2)
        {
            if(b.x > this.x && b.x < this.x + this.width)
            {
                directions[0] = -1;
            }
            else if(b.y > this.y && b.y < this.y + height)
            {
                directions[1] = -1;
            }
            else
            {
                directions[0] = -1;
                directions[1] = -1;
            }
        }

        return directions;

        /*if(b.preventionDistance < 0)
        {
            if(b.x >= this.x - b.width/2 && b.x <= this.x + this.width + b.width/2
            && b.y >= this.y - b.width/2 && b.y <= this.y + this.height + b.width/2)
            {
                int diameterYStart = b.y - b.width/2;
                int diameterXStart = b.x - b.width/2;

                if(b.x >= this.x && b.x <= this.x + this.width)
                {
                    b.diry *= -1;
                    if(this.y + this.height >= diameterYStart && this.y + this.height <= diameterYStart + b.width)
                    {
                        b.preventionDistance = this.y + this.height - diameterYStart + 1;
                    }
                    else if(this.y >= diameterYStart && this.y <= diameterYStart + b.width)
                    {
                        b.preventionDistance = this.y - diameterYStart + b.width + 1;
                    }
                }
                else if(b.y >= this.y && b.y <= this.y + height)
                {
                    b.dirx *= -1;
                    if(this.x + this.width >= diameterXStart && this.x + this.width <= diameterXStart + b.width)
                    {
                        b.preventionDistance = this.x + this.width - diameterXStart + 1;
                    }
                    else if(this.x >= diameterXStart && this.x <= diameterXStart + b.width)
                    {
                        b.preventionDistance = this.x - diameterXStart + b.width + 1;
                    }
                }
                else
                {
                    b.dirx *= -1;
                    b.diry *= -1;
                    b.preventionDistance = cornerCollision(b) + 1;
                }

                return true;
            }
        }

        return false;*/
    }

    private int cornerCollision(Ball b)
    {
        int upperLeft[] = {this.x, this.y};
        int lowerLeft[] = {this.x, this.y + this.height};
        int upperRight[] = {this.x + this.width, this.y};
        int lowerRight[] = {this.x + this.width, this.y + this.height};

        double d = distance(b.x, b.y, upperLeft[0], upperLeft[1]);
        if(d <= b.width/2)
        {
            return b.width/2 - (int)d;
        }

        d = distance(b.x, b.y, lowerLeft[0], lowerLeft[1]);
        if(d <= b.width/2)
            return b.width/2 - (int)d;

        d = distance(b.x, b.y, upperRight[0], upperRight[1]);
        if(d <= b.width/2)
            return b.width/2 - (int)d;

        d = distance(b.x, b.y, lowerRight[0], lowerRight[1]);
        if(d <= b.width/2)
            return b.width/2 - (int)d;

        return -2;
    }

    public double distance(int x1, int y1, int x2, int y2)
    {
        return Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2));
    }


}
