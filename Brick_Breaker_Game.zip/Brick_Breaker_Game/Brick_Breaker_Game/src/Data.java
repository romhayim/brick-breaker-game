import java.io.Serializable;

public class Data implements Serializable {

    int x;


    int y;
    int brick_i;
    int brick_j;
    int live;
    boolean ingame;
    int score;
    public Data(){}

    public Data(int x, int y, int brick_i, int brick_j, int live, boolean ingame,int score) {
        this.x = x;
        this.y = y;
        this.brick_i = brick_i;
        this.brick_j = brick_j;
        this.live = live;
        this.score = score;
        this.ingame = ingame;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getBrick_i() {
        return brick_i;
    }

    public void setBrick_i(int brick_i) {
        this.brick_i = brick_i;
    }

    public int getBrick_j() {
        return brick_j;
    }

    public void setBrick_j(int brick_j) {
        this.brick_j = brick_j;
    }

    public int getLive() {
        return live;
    }

    public void setLive(int live) {
        this.live = live;
    }

    public boolean isIngame() {
        return ingame;
    }

    public void setIngame(boolean ingame) {
        this.ingame = ingame;
    }


    @Override
    public String toString() {
        return "Data{" +
                "x=" + x +
                ", y=" + y +
                ", brick_i=" + brick_i +
                ", brick_j=" + brick_j +
                ", live=" + live +
                ", ingame=" + ingame +
                ", score=" + score +
                '}';
    }
}

