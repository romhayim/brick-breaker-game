import javax.swing.*;
import java.awt.*;
import java.util.Arrays;

public class Brick extends Rectangle implements Runnable{
    public int lives = 5;
    public boolean checked;
    Color[] colors = {Color.RED, Color.ORANGE, Color.WHITE};
    Image[] brick_images = new Image[lives];
    BrickBreakerPanel panel;
    int i,j;
    Brick(int x, int y, int width, int height, BrickBreakerPanel panel,int i,int j)
    {
        super(x, y, width, height);
        this.i = i;
        this.checked = true;
        this.j = j;
        this.panel = panel;
        brick_images[0] = new ImageIcon("brick1.png").getImage();
       brick_images[1] = new ImageIcon("brick2.png").getImage();
        brick_images[2] = new ImageIcon("brick3.png").getImage();
        brick_images[3] = new ImageIcon("brick4.png").getImage();
        brick_images[4] = new ImageIcon("brick5.png").getImage();
    }

    public void draw(Graphics g) {
        /*g.setColor(colors[lives - 1]);
        g.fillRect(x, y, width, height);*/

        g.drawImage(brick_images[lives - 1], x, y, width, height, null);
    }

    @Override
    public void run() {

        Ball b = panel.ball;
        int [] noCollison = {1, 1};

        while (true)
        {
            int directions[] = collision(b);

            if(!isInCollision)
            {
                if (!Arrays.equals(noCollison, directions))
                {
                    isInCollision = true;
                    b.diry *= directions[0];
                    b.dirx *= directions[1];
                    panel.broken_brick_i =i;
                    panel.broken_brick_j = j;
                    panel.score +=10;
                    lives--;
                    panel.broken_live = lives;
                }
            }
            else {
                if (Arrays.equals(noCollison, directions))
                {
                    isInCollision = false;
                }
            }

            if(lives == 0)
            {
                panel.score +=20;
                break;
            }

            try {
                Thread.sleep(2);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            if(panel.game_ended)
                break;

            panel.repaint();

        }
    }
}
