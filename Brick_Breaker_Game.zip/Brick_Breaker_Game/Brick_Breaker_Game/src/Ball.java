import javax.swing.*;
import java.awt.*;
import java.util.Arrays;

public class Ball extends Thread{

    volatile public int x, y, width, dirx, diry;
    private BrickBreakerPanel panel;

    Ball(int x, int y, int width, BrickBreakerPanel panel)
    {
        this.x = x ;
        this.y = y;
        this.width = width;
        this.panel = panel;
    }

    public void draw(Graphics g)
    {
        /*g.setColor(Color.WHITE);
        g.fillOval(x - width/2, y - width/2, width, width);*/

        Image ball_img = new ImageIcon("ballt.png").getImage();
        g.drawImage(ball_img, x - width/2, y - width/2, width, width, null);
    }

    @Override
    public void run() {
        this.dirx = 1;
        this.diry = 1;
        int [] noCollison = {1, 1};

        while(true)
        {
            if(panel.getHeight() != 0)
            {
                if(x + width/2 >= panel.getWidth())
                    dirx = -1;
                if(x - width/2 <= 0)
                    dirx = 1;
                if(y + width/2 >= panel.getHeight())
                {
                    panel.game_ended = true;
                }
                if(y - width/2 <= 0)
                    diry = 1;

            }

            x += dirx;
            y += diry;

            Racket r = panel.racket;
            int directions[] = r.collision(this);
            if(!r.isInCollision)
            {
                if (!Arrays.equals(noCollison, directions))
                {
                    diry *= directions[0];
                    dirx *= directions[1];
                }
            }
            else {
                if (Arrays.equals(noCollison, directions))
                {
                    r.isInCollision = false;
                }
            }

            try {
                Thread.sleep(2);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            if(panel.game_ended)
                break;

            panel.repaint();
        }
    }
}
