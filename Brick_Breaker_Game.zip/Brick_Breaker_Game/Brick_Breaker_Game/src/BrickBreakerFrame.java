import javax.swing.*;

public class BrickBreakerFrame extends JFrame {

    public int width;
    public int height;

    BrickBreakerFrame(int width, int height)
    {
        this.width = width;
        this.height = height;
        setSize(width, height);
        add(new BrickBreakerPanel());
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String args[])
    {
        BrickBreakerFrame f = new BrickBreakerFrame(1280, 720);
    }
}
